<?php 
		include('connection.php'); 

		
		
		$submitbutton= $_POST['game'];

		
		$status= $_GET['status'];
		$room = $_POST['room_name'];
		$player_code= $_POST['player_code'];
		$game_bay_id= $_POST['game_bay_id'];
		$message = '';
		
	
				
					$mysql_qry = "UPDATE tbl_game_bay SET $room = '$player_code' where status IN (6,7,8,9,10,11)";

					if($conn->query($mysql_qry)=== TRUE){
						

						
								   header('Location: player_under_me.php');
								  
					}else{
						
						echo "cannot perform this action".$conn->error;
						
					}
					
					$conn->close();
								
			

	


?>
	

	


