<?php 
		include('connection.php'); 
		include('session.php'); 
		$table = "tbl_reg"; 
		$id = $user_session;
		$submitbutton= $_POST['updateprofile'];
		$message = '';
	
    $password =$_POST['password'];		

						 $sql2 = "UPDATE $table 
							 SET password  = '$password' where  user_id = '$id';";
	
					if($conn->query($sql2)=== TRUE){
						 $message = '<label class="text-danger">Profile updated</label>';
						header('Location: profile.php'); 
						
							 
					}else{
						
						 $message = '<label class="text-danger">Profile not updated</label>';
						
					}
				
					
					$conn->close();
								
			 



?>