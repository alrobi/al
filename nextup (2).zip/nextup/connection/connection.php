<?php
ob_start();
$user = ""; 
$password = ""; 
$host = "localhost"; 
$dbase = "nextapp";  


	$conn = mysqli_connect($host, $user, $password, $dbase) or die('unable to connect');
	if(mysqli_connect_error($conn)){
		header('Location: page_500.html');
	}
?>
