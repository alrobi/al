<?php
ob_start();
$connect = new PDO('mysql:host=169.239.217.30;dbname=smlprojectsco_nextup', 'smlprojectsco_nextup', 'uL75)fB@YM5I');
?>