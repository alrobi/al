<?php
ob_start();
$connect = new PDO('mysql:host=localhost;dbname=nextapp', '', '');
?>