<?php 
include('connection/session.php'); 
 include('connection/connection.php'); 

  $status = "verified";
  $id = $player_session;
    $result1 = mysqli_query($conn, "SELECT * FROM tbl_reg where player_code != '$id'");
    $total_player_reg = mysqli_num_rows($result1);

  $status = "Accepted";
  $inviter = $player_session;
    $result2 = mysqli_query($conn, "SELECT * FROM tbl_reg where inviter_player_code =  '$inviter' and player_code != '$id' ");
    $total_player_joined = mysqli_num_rows($result2);

  $status = "Top Up";
  $sql9 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status = '$status'"; 
   
         $detailed = mysqli_query($conn,$sql9);
  while($row = mysqli_fetch_array($detailed)){
    $availabl_ewallet = $row['amount'];
  }

  $status = "Paid";
  $sql99 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status = '$status'"; 
   
         $detailed9 = mysqli_query($conn,$sql99);
  while($row = mysqli_fetch_array($detailed9)){
    $paid_ewallet = $row['amount'];

    $available_ewallet = $availabl_ewallet - $paid_ewallet;
  }

   $sqlcurrencydisplay = "select currency from tbl_reg where player_code = '$player_session'"; 
   
         $currencydisplay = mysqli_query($conn,$sqlcurrencydisplay);
  while($row = mysqli_fetch_array($currencydisplay)){
    $currency = $row['currency'];
    if($currency == 'DOLLAR'){
      $currency = "$";
    }
    else if($currency == 'ZAR'){
      $currency = "R";
    }

  }

    //INVITATION OPTIONS
    $whatsapp = 'https://smlprojects.co.za/nextup/register.php?player_code='.$player_session;
    $android = 'https://smlprojects.co.za/nextup/register.php?player_code='.$player_session;
    $ios = 'https://smlprojects.co.za/nextup/register.php?player_code='.$player_session;
  

   
 


   ?>