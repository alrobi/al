<?php
include('connection/session.php');  
include('connection/connection.php');  
  $player_code = $player_session;
      $sql9 = "select user_id, firstname, surname, currency,emailaddress,player_code,password from tbl_reg where player_code = '$player_code'"; 
   
         $detailed = mysqli_query($conn,$sql9);
   

  while($row = mysqli_fetch_array($detailed)){
    $firstname =$row['firstname'];
    $surname =$row['surname'];
     $currency =$row['currency'];
    $emailaddress =$row['emailaddress'];
    $password =$row['password'];
    $user_id =$row['user_id'];
    


}
  ?>