<!DOCTYPE html>

<?php
//register.php

include('connection/pdo_connection.php');

if(isset($_SESSION['user_id']))
{
 header("location:index.php");
}

$message = '';

if(isset($_POST["register"]))
{
 $query = "
 SELECT * FROM tbl_reg 
 WHERE emailaddress = :emailaddress
 ";
 $statement = $connect->prepare($query);
 $statement->execute(
  array(
   ':emailaddress' => $_POST['emailaddress']
  )
 );
 $no_of_row = $statement->rowCount();

 if($no_of_row > 0)
 {
  $message = '<label class="text-danger">Email Already Exits</label>';
 }
 else
 {
  include('connection/pdo_connection.php');
  $password = rand(1000,9999);
  $player_code = rand(1000000000,9999999999); 
  $user_encrypted_password = password_hash($password, PASSWORD_DEFAULT);
  $user_activation_code = md5(rand());

  $user_email_status = "Not verified";
  $role = "Player";
   $currency = "ZAR";
   $wallet_verification = "Not verified";
  $insert_query = "
  INSERT INTO tbl_reg 
  (firstname, surname, inviter_player_code,emailaddress,player_code,password,user_activation_code, user_email_status,currency)
  VALUES (:firstname,:surname,:inviter_player_code,:emailaddress,:player_code,:password,:user_activation_code,:user_email_status,:currency)
  ";
  $statement = $connect->prepare($insert_query);

  $statement->execute(
   array(
    ':firstname'   => $_POST['firstname'],
    ':surname'   => $_POST['surname'],
    ':inviter_player_code'   => $_POST['inviter_player_code'],
    ':emailaddress'   => $_POST['emailaddress'],
    ':player_code'   => $player_code,
    ':password'  => $password,
    ':user_activation_code' => $user_activation_code,
    ':user_email_status' => $user_email_status,
    ':currency' => $currency
   )
  );

  $result = $statement->fetchAll();
  

  if(isset($result))
  {
    $emailaddress = $_POST['emailaddress'];
    $email_to = "$emailaddress";

    $email_subject = "WELCOME TO NEXT UP";
 
 
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
    
    
      $url = "https://smlprojects.co.za/nextup/email_verification.php?activation_code=".$user_activation_code;
    
    $username = "NEXT UP Info\n"; // required
    $body = "Thanks for Registration. Your Username is ".$emailaddress."\n\nYour password: ".$password."\n\nThis account will work only after your email verification.\n\nPlease Open this link to verified your email address".$comments."\n\nLink: ".$url."\n\n\nThank You\n\n\n
      ";// required
    $email_from = "roland@smlprojects.co.za";         // required
 
 
    //validation expected data exists
    if(!isset($username) ||!isset($body)|| !isset($email_from)) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
 
   
  $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email_from)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }
    $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$username)) {
    $error_message .= 'The Username you entered does not appear to be valid.<br />';
  }
 
  if(strlen($error_message) > 0) {
    died($error_message);
  }
    $email_message = "See details below.\n\n";
 
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
    $email_message .= "Name: ".clean_string($username)."\n";
    $email_message .= "NB: ".clean_string($body)."\n";
  
 
// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers); 
$message = '<label class="text-success">Register Done, Please check your mail.</label>';
  }
 }
}

?>