<!DOCTYPE html>

<?php
//register.php

include('connection/pdo_connection.php');

if(isset($_SESSION['user_id']))
{
 header("location:index.php");
}

$message = '';

if(isset($_POST["register"]))
{
 $query = "
 SELECT * FROM tbl_reg 
 WHERE emailaddress = :emailaddress
 ";
 $statement = $connect->prepare($query);
 $statement->execute(
  array(
   ':emailaddress' => $_POST['emailaddress']
  )
 );
 $no_of_row = $statement->rowCount();
 if($no_of_row > 0)
 {
  $message = '<label class="text-danger">Email Already Exits</label>';
 }
 else
 {
  $password = rand(1000,9999);
  $player_code = rand(1000000000,9999999999); 
  $user_encrypted_password = password_hash($password, PASSWORD_DEFAULT);
  $user_activation_code = md5(rand());
  
  $user_email_status = "Not verified";
  $role = "Player";
   $wallet_verification = "Not verified";
  $insert_query = "
  INSERT INTO tbl_reg 
  (firstname, surname, inviter_player_code,emailaddress,player_code,password,user_activation_code, user_email_status,role,wallet_verification)
  VALUES (:firstname, :surname, :inviter_player_code,:emailaddress,:player_code,:password, :user_activation_code, :user_email_status,:role,:wallet_verification)
  ";
  $statement = $connect->prepare($insert_query);
  $statement->execute(
   array(
    ':firstname'   => $_POST['firstname'],
    ':surname'   => $_POST['surname'],
    ':inviter_player_code'   => $_POST['inviter_player_code'],
    ':cellno'   => $_POST['cellno'],
    ':emailaddress'   => $_POST['emailaddress'],
    ':player_code'   => $player_code,
    ':password'  => $password,
    ':user_activation_code' => $user_activation_code,
    ':user_email_status' => $user_email_status,
    ':role' => $role,
    ':wallet_verification' => $wallet_verification
   )
  );
  $result = $statement->fetchAll();
  if(isset($result))
  {
  $base_url = "http://smlprojects.co.za/nextup/";
   $mail_body = "
   <p>Hi ".$_POST['firstname'].",</p>
   <p>Thanks for Registration. Your Username is ".$emailaddress."</p>
   <p>Your password is ".$password."</p>
   <p>Your unique player code is ".$player_code."</p>
   <p>This account will work only after your email verification.</p>
   <p>Please Open this link to verified your email address - ".$base_url."email_verification.php?activation_code=".$user_activation_code."
   <p>Best Regards,<br />Nextup</p>
   ";
   require 'class/class.phpmailer.php';
   $mail = new PHPMailer;
   $mail->IsSMTP();        //Sets Mailer to send message using SMTP
   $mail->Host = 'mail.smlprojects.co.za';  //Sets the SMTP hosts of your Email hosting, this for Godaddy
   $mail->Port = '465';        //Sets the default SMTP server port
   $mail->SMTPAuth = true;       //Sets SMTP authentication. Utilizes the Username and Password variables
   $mail->Username = '';     //Sets SMTP username
   $mail->Password = '';     //Sets SMTP password
   $mail->SMTPSecure = 'ssl';       //Sets connection prefix. Options are "", "ssl" or "tls"
   $mail->From = 'info@nextup.co.za';   //Sets the From email address for the message
   $mail->FromName = 'Next Up';     //Sets the From name of the message
   $mail->AddAddress($_POST['emailaddress'], $_POST['firstname']);  //Adds a "To" address   
   $mail->WordWrap = 50;       //Sets word wrapping on the body of the message to a given number of characters
   $mail->IsHTML(true);       //Sets message type to HTML    
   $mail->Subject = 'Email Verification';   //Sets the Subject of the message
   $mail->Body = $mail_body;       //An HTML or plain text message body
   if($mail->Send())        //Send an Email. Return true on success or false on error
   {
    $message = '<label class="text-success">Register Done, Please check your mail.</label>';
   }
  }
 }
}

?>