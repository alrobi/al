<?php 
		include('connection/connection.php'); 
		include('display/dashboard_display.php'); 
		$sqlcurrencydisplay = "select currency from tbl_reg where player_code = '$player_session'"; 
   
         $currencydisplay = mysqli_query($conn,$sqlcurrencydisplay);
  while($row = mysqli_fetch_array($currencydisplay)){
    $currency = $row['currency'];
   if($currency == 'ZAR'){
      $currency = "R";
        $gethubdesc = "SELECT btc,zar_sa from tbl_currency where id = 4";
          
          $resultdesc1 = mysqli_query($conn,$gethubdesc);
           while($row = mysqli_fetch_array($resultdesc1))
            {
             
              $zar_sa = $row['zar_sa'];
               $available_ewallet = $available_ewallet;
              
            }
    }

  }
  //end of select currency
		$submitbutton= $_POST['enter_game'];

			$status= $_POST['status'];
		$room_name = $_POST['room_name'];
		$player_code= $_POST['player_code'];
		
		$message = '';
		$st= "Paid";
		$amount = 50;
		$time_date = date("Y M d ,g:1 a");
		$message = '';
	
				if($available_ewallet >= $zar_sa){
						$mysql_qry = "UPDATE tbl_game_bay4 SET $room_name = $player_code where status = '$status' ";

					if($conn->query($mysql_qry)=== TRUE){
						
						$mysql_qry3 = "insert into tbl_wallet(player_code,amount,time_date,status)
									values('$player_code','$amount','$time_date','$st')";
									if($conn->query($mysql_qry3)=== TRUE){
										$message = 'Successfull';
										header('Location: dashboard4.php');
									}
						
								  
					}else{
						
						echo "cannot perform this action".$conn->error;

						
					}
				}else{
					$message = 'Ooups refund your wallet';
				}
				
					
					$conn->close();
								
			

	

								   

?>