<?php 
		include('connection/connection.php'); 
		include('connection/session.php'); 
		$table = "tbl_reg"; 
		$id = $user_session;
		$submitbutton= $_POST['updateprofile'];
		$message = '';
	
    $password =$_POST['password'];	
      $currency =$_POST['currency'];		

						 $sql2 = "UPDATE $table 
							 SET currency  = '$currency' where  user_id = '$id';";
	
					if($conn->query($sql2)=== TRUE){
						 $message = '<label class="text-danger">Profile updated</label>';
						header('Location: profile.php'); 
						
							 
					}else{
						
						 $message = '<label class="text-danger">Profile not updated</label>';
						
					}
				
					
					$conn->close();
								
			 



?>