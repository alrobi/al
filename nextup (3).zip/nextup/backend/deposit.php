<?php 
		include('connection.php');
		include('session.php');  
		$player_code = $player_session;
		$submitbutton= $_POST['update_invitation'];
		$time_date = date("Y M d ,g:1 a");
		$status = "Top Up";
		$wallet_verification = "verified";
		$message = '';
	
    		$amount =$_POST['amount'];
   

						$mysql_qry = "insert into tbl_wallet(player_code,amount,time_date,status)
					values('$player_code','$amount','$time_date','$status')";
	
					if($conn->query($mysql_qry)=== TRUE){
						$mysql_qry2 = "UPDATE tbl_reg SET wallet_verification = '$wallet_verification' where player_code = '$player_code' ";

					if($conn->query($mysql_qry2)=== TRUE){

						 $message = '<label class="text-danger">Successful</label>';
						header('Location: dashboard.php'); 
					}else{
						$message = '<label class="text-danger">Not accepted</label>';
					}
					
						
							 
					}else{
						
						 $message = '<label class="text-danger">Not accepted</label>';
						
					}
				
					
					$conn->close();
								
			 



?>