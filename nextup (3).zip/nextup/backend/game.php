<?php 
		include('connection.php'); 
	
			

if(isset($_GET["id"]))
{
	

 	$player_code = $_POST["player_code"];
 	$room_name = $_POST["room_name"];
 	

 $mysql_qry = "update tbl_game_bay set $room_name = '$player_code' where status =  '$id'";
		
						if($conn->query($mysql_qry)=== TRUE){
							

									  header('Location: play_under_me.php');
						}else{
							echo "cannot perform this action".$conn->error;
						}
 
}

	


?>
	


