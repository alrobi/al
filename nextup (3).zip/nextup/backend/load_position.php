 <?php  
 //load_data.php  
  $connect = mysqli_connect("169.239.217.30", "smlprojectsco_nextup", "uL75)fB@YM5I", "smlprojectsco_nextup"); 
 $output = '';  
  $room = $_POST["room_name"];
 if(isset($_POST["room_name"]))  
 {  
      if($_POST["room_name"] != '')  
      {  
          $sql = "SELECT status FROM tbl_game_bay  WHERE $room  = '$empty' and status NOT IN (1,2,3,4,5)";   
      }  
      
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '<option></option><option value="'.$row["status"].'" class="">'.$row["status"].'</option>'; 
           
      }  
      echo $output;  
 }  
 ?>