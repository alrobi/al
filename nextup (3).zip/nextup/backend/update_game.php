<?php 
		include('connection/connection.php'); 


			
		$submitbutton= $_POST['game'];

		
		$status= $_POST['status'];
		$room = $_POST['room_name'];
		$player_code= $_POST['player_code'];
		$game_bay_id= $_POST['game_bay_id'];
		$st= "Paid";
		$amount = 50;
		$time_date = date("Y M d ,g:1 a");
		$message = '';
	
				
					$mysql_qry = "UPDATE tbl_game_bay SET $room = $player_code where status = '$status' ";

					if($conn->query($mysql_qry)=== TRUE){
							$mysql_qry3 = "insert into tbl_wallet(player_code,amount,time_date,status)
									values('$player_code','$amount','$time_date','$st')";
						if($conn->query($mysql_qry3)=== TRUE){
							  header('Location: dashboard.php');
						}
								  
					}else{
						
						echo "cannot perform this action".$conn->error;

						
					}
					
					$conn->close();
								
			

	



						
								 
?>
	

	


