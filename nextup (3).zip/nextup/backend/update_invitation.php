<?php 
		include('connection.php'); 
		
		$submitbutton= $_POST['acceptrequest'];
		$message = '';
	
    
    		$player_invited =$_POST['player_invited'];
   

						$mysql_qry = "insert into tbl_game_bay(players)
					values('$player_invited')";
	
					if($conn->query($mysql_qry)=== TRUE){
					
						 $message = '<label class="text-danger">Successful</label>';
						header('Location: https://smlprojects.co.za/nextup/dashboard.php'); 
						
							 
					}else{
						
						 $message = '<label class="text-danger">Not accepted</label>';
						
					}
				
					
					$conn->close();
								
			 



?>