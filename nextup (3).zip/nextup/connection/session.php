<?php
	ob_start();
	
	 $connect = mysqli_connect("169.239.217.30", "smlprojectsco_nextup", "uL75)fB@YM5I", "smlprojectsco_nextup"); 
	
	session_start();
	$user_check = $_SESSION['login_user'];

	
	$ses_sql = "select user_id, player_code,firstname,emailaddress from tbl_reg where emailaddress = '$user_check'";
	$result = mysqli_query($connect, $ses_sql); 
	$row = mysqli_fetch_assoc($result);
	$login_session = $row['firstname']; 
	$user_session = $row['user_id'];
	$player_session = $row['player_code'];
	$email_session = $row['emailaddress'];
	
	
	if(!isset($login_session)){
		mysqli_close($connect);
		header("Location: index.php");
	}
	
?>
