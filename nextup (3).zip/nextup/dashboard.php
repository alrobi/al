<?php include('connection/session.php');  ?> 
<!DOCTYPE html>
<?php include('connection/connection.php');  ?> 
<?php include('display/dasboard_display.php');  ?>
<?php
  $pp = "";
     $status = 11;
     $statusdel = 1;
     $i = 0;
     $room_number = 1;  

      //Determines how many column in the db start with room_
      $room_query = "select * from information_schema.columns where table_name='tbl_game_bay' and column_name like 'room_%'";
      $rooms = mysqli_query($conn,$room_query);
      while($row = mysqli_fetch_array($rooms))
      {
        // echo $row['COLUMN_NAME'];
        $current_room = $row['COLUMN_NAME'];
        $room_number = str_replace('room_', '', $current_room);

        //Check that the room is full
        $query = "SELECT * FROM `tbl_game_bay` WHERE room_{$room_number} = ''";
        $rowCount = 0;

        if ($result=mysqli_query($conn,$query))
        {
          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);
          
          // Free result set
          mysqli_free_result($result);
        }

        if(checkifroomexist($room_number)){
          if($rowcount == 0){
          //You can add a new column
                 $total = determinetotalroom();
            splitColumnifnotexist($total,$room_number,$statusdel);
            
           }
        }else{
           if($rowcount == 0){
          //You can add a new column
              splitColumn($room_number, $statusdel);
           }
        }

        $val1 = select_row_value($room_number,1);
        $val2 = select_row_value($room_number,2);
        $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

        if(empty($val1) && empty($val2)){
             $update_1_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            } 
        }

        //if there is no empty column in room_{$room_number}, we split it
           
      //echo $sql233;
       
      }//end of while loop

      function display($room_number){
        global $conn;
         $totalroom = determinetotalroom();
    $array = array();
    for($x = 0; $x < $totalroom; $x++){
    $query = "select room_{$room_number} from tbl_game_bay order by game_bay_id"; 
        
      }
     }
      function checkifroomexist($room_number){
        //check if column  existing
         global $conn;
        $val = false;
          $query202 = "SELECT column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay') as name where column_name like 'room_{$room_number}' and column_name like 'room_%'";
        
          $result202 = mysqli_query($conn,$query202);
           while($row = mysqli_fetch_array($result202))
            {
              $room_names = $row['name'];
              $val = true;
              
            }
            return $val;
      } 
      //echo checkifroomexist(2);

      function determinetotalroom(){
        //count number of column already existing
         global $conn;
         $totalroom= 0;
          $query20 = "SELECT count(*) as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay') as name where column_name like 'room_%'";
          $total_room = 0;
          $result20=mysqli_query($conn,$query20);
           while($row = mysqli_fetch_array($result20))
            {
              $total_room = $row['name'];
              
            }
            return $total_room;
      }         
      //echo determinetotalroom();
        
        function splitColumn($room_number, $statusdel){
          global $conn;
           $pp = "";
           $null = "";
          $sqldel = "UPDATE tbl_game_bay set room_{$room_number} = '$pp' WHERE status = '$statusdel'";
          // echo $sqldel;

          if($conn->query($sqldel)=== TRUE){
              $sqladd = "ALTER TABLE tbl_game_bay ADD room_".($room_number + 1)." VARCHAR(255) not null after room_{$room_number}";
              if($conn->query($sqladd)=== TRUE){
                  $msqlodd = "UPDATE tbl_game_bay SET  room_".($room_number + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                   $sqleven =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){
                              $row_at_eleven = select_row_value($room_number,11);
                       if(empty($row_at_eleven)){
                        //even
                           $val_at_2 =  select_row_value($room_number,2);
                            $val_at_4 = select_row_value($room_number,4);
                            $val_at_6 = select_row_value($room_number,6);
                            $val_at_8 = select_row_value($room_number,8);
                            $val_at_10 = select_row_value($room_number,10);

                            $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

                             $update_1_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_2' WHERE game_bay_id = 1";
                            if($conn->query($update_1_even)=== TRUE){
                              $update_2_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_4' WHERE game_bay_id = 2";
                            if($coqenn->query($update_2_even)=== TRUE){
                               $update_3_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_6' WHERE game_bay_id = 3";
                            if($conn->query($update_3_even)=== TRUE){
                                   $update_4_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_8' WHERE game_bay_id = 4";
                            if($conn->query($update_4_even)=== TRUE){
                                   $update_5_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_10' WHERE game_bay_id = 5";
                            if($conn->query($update_5_even)=== TRUE){
                                   $removerow =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            }
                       }else{
                            $update_1_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            }
                       }
                      }
                    }
                }
           }


        }//end of function

        function splitColumnifnotexist($totalcolumn,$room_number ,$statusdel){
          global $conn;
           $pp = "";
           $null = "";
          $sqldel = "UPDATE tbl_game_bay set room_{$room_number} = '$pp' WHERE status = '$statusdel'";
          // echo $sqldel;

          if($conn->query($sqldel)=== TRUE){
              $sqladd = "ALTER TABLE tbl_game_bay ADD room_".($totalcolumn + 1)." VARCHAR(255) not null after room_{$totalcolumn}";
              if($conn->query($sqladd)=== TRUE){
                  $msqlodd = "UPDATE tbl_game_bay SET  room_".($totalcolumn + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                   $sqleven =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){
                          $row_at_eleven = select_row_value($room_number,11);
                       if(empty($row_at_eleven)){
                        //even
                           $val_at_2 =  select_row_value($room_number,2);
                            $val_at_4 = select_row_value($room_number,4);
                            $val_at_6 = select_row_value($room_number,6);
                            $val_at_8 = select_row_value($room_number,8);
                            $val_at_10 = select_row_value($room_number,10);

                            $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

                             $update_1_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_2' WHERE game_bay_id = 1";
                            if($conn->query($update_1_even)=== TRUE){
                              $update_2_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_4' WHERE game_bay_id = 2";
                            if($conn->query($update_2_even)=== TRUE){
                               $update_3_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_6' WHERE game_bay_id = 3";
                            if($conn->query($update_3_even)=== TRUE){
                                   $update_4_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_8' WHERE game_bay_id = 4";
                            if($conn->query($update_4_even)=== TRUE){
                                   $update_5_even =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_10' WHERE game_bay_id = 5";
                            if($conn->query($update_5_even)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            }
                       }else{
                            $update_1_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            }
                       }
                      }
                    }
                }
           }



        }//end of function

         function updaterow($room_number){
          global $conn;
           $pp = "";
          $sqldel = "UPDATE tbl_game_bay set room_{$room_number} = '' WHERE status = '$statusdel'";
          // echo $sqldel;

          if($conn->query($sqldel)=== TRUE){
              $sqladd = "ALTER TABLE tbl_game_bay ADD room_".($totalcolumn + 1)." VARCHAR(255) not null after room_{$room_number}";
              if($conn->query($sqladd)=== TRUE){
                  $msqlodd = "UPDATE tbl_game_bay SET  room_".($totalcolumn + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                   $sqleven =  "UPDATE tbl_game_bay SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){
                       
                      }
                    }
                }
           }


        }
        
    

      function select_row_value($room_number,$row_number){
        //count number of column already existing
         global $conn;
        
          $query200 = "SELECT room_{$room_number} as row_value from tbl_game_bay where game_bay_id = '$row_number'";
          
          $result200 = mysqli_query($conn,$query200);
           while($row = mysqli_fetch_array($result200))
            {
              $value = $row['row_value'];
              
            }
            return $value;
      } 

 

    //available room
    $pp = "";
     $status = 11;
     $statusdel = 1;
     $room = "room";
         $sql2555 = "select column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay') as name where column_name like '$room%'";
   
         $all_lists = mysqli_query($conn,$sql2555);
        

         //available room
    
     $room = "room";
         $sqlroomoption = "select column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay') as name where column_name like '$room%'";
   
         $room_list = mysqli_query($conn,$sqlroomoption);
        





$query2 = "select inviter_player_code from tbl_reg where inviter_player_code  = '$player_session'"; 
$result2 = mysqli_query($conn, $query2);

while($row = mysqli_fetch_array($result2)){

    if ($row['inviter_player_code'] == $row['room']) {
 
        
   $icon = "glyphicon glyphicon-ok-circle";
 } else {
  $icon = "";
 }
}


?>
<?php
     $sqlcurrencydisplay = "select currency from tbl_reg where player_code = '$player_session'"; 
   
         $currencydisplay = mysqli_query($conn,$sqlcurrencydisplay);
  while($row = mysqli_fetch_array($currencydisplay)){
    $currency = $row['currency'];
    if($currency == 'DOLLAR'){
      $currency = "$";
        $gethubdesc = "SELECT btc,dollar_d from tbl_currency where id = 1";
          
          $resultdesc1 = mysqli_query($conn,$gethubdesc);
           while($row = mysqli_fetch_array($resultdesc1))
            {
              $btc = $row['btc'];
              $zar_sa = $row['dollar_d'];
                $available_ewallet = $available_ewallet * 0.059;
              
            }
    }
    else if($currency == 'ZAR'){
      $currency = "R";
        $gethubdesc = "SELECT btc,zar_sa from tbl_currency where id = 1";
          
          $resultdesc1 = mysqli_query($conn,$gethubdesc);
           while($row = mysqli_fetch_array($resultdesc1))
            {
              $btc = $row['btc'];
              $zar_sa = $row['zar_sa'];
               $available_ewallet = $available_ewallet;
              
            }
    }

  }
 
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Next Up!</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/New%20Folder/sb-admin-2.compiled.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body><!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon">
          <i class="fa fa-angle-double-up" aria-hidden="true"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><strong>Next Up!</strong></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-home"></i>
          <span>Dashboard</span></a>
      </li>
      <li class="nav-item">
      </li>
     <!-- <!--  <li class="nav-item active">
       
        <a class="nav-link" data-toggle="modal" data-target="#edit-<?php echo $row['game_bay_id']?>" >
          <i class="fas fa-fw fa-eye"></i>
          <span>Secure spot</span>
        </a>
      </li> --> -->

      <li class="nav-item active">
         <a href="#modal-table" role="button" class="nav-link" data-toggle="modal">
           <i class="fa fa-plus" aria-hidden="true"></i>
          <span>Invite Player</span></a>
         </a>
        
         
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="documents.php">
          <i class="fa fa-plus" aria-hidden="true"></i>
          <span>FICA</span></a>
      </li>
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-warning topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md- mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="username" style="font-size: 26px;line-height: 24px;letter-spacing: 0.213em;font-weight: 500;"><?php echo $login_session; ?><i class="fa fa-caret-down" aria-hidden="true"></i>
                </span>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="log_out.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br><br>

          <!-- Content Row -->
         
          <div class="row">
             

            <!-- Total Players Card -->
          <!--   <div class="col-xl-3 col-md-6 mb-4">
              <a href="full_player_list.php" class="stretched-link"></a>
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                        Players:</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_player_reg; ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-user fa-2x text-dark-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->

            <!-- Total Earnings Card -->
            <div class="col-xl-6 col-md-6 mb-4">
              <a href="#" class="stretched-link"></a>
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total
                        Earnings:</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"></div>
                    </div>
                    <div class="col-auto">
                      <h3><?php echo $currency; ?></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Wallet Card -->
            <div class="col-xl-6 col-md-6 mb-4">
              <a href="top_up.php" class="stretched-link"></a>
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Wallet:
                      </div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo number_format($available_ewallet,2); ?>
                          </div>

                        </div>


                      </div>
                    </div>
                    <div class="col-auto">
                     <h3> <?php echo $currency; ?></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Players Invited Card-->
          <!--   <div class="col-xl-3 col-md-6 mb-4">
              <a href="#" class="stretched-link"></a>
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                        People joined under me:
                      </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_player_joined; ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-address-card fa-2x text-dark-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->
          </div>

          <!--Table/Game Bay-->
          <div class="row">
            <div class="box col-md-12">
              <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <h2><i class="glyphicon glyphicon-user"></i> GAME HUB </h2>

                  
                </div>
                <div class="box-content">
                 <?php echo $message; ?>
                 <div class="alert alert-info"><a class="btn btn-link" data-toggle="" data-target="#edit-<?php echo $row['game_bay_id']?>" >Secure next spot:<br/><?php echo $player_session?> 
                   <div aria-hidden="true" aria-labelledby="addLabel-<?php echo $row['game_bay_id']?>" role="dialog" tabindex="-1" id="edit-<?php echo $row['game_bay_id']?>" class="modal fade">
                                  <form id="project_form" action="start_playing.php" method="post" enctype="multipart/form-data">
                                          <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                  <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                      <h4 class="modal-title" id="addLabel-<?php echo $row['game_bay_id']?>"></h4>
                                                  </div>
                                                 
                                                  <div class="modal-body" >
                                                     
                                                    
                                                   
                                                          <select id="room_name" name="room_name" placeholder="" class="form-control" title="Select game hub" required>
                                                       <option value=""  disabled selected hidden>SELECT ROOM </option>
                                                         <?php
                                                            while($row = mysqli_fetch_array($room_list)){
                                                               
                                                                                                              
                                                        ?> 
                                                        
                                                    <option value="<?php echo $row['name']?>"><?php echo $row['name']?></option>
                                                    
                                                     <?php
                        
                                             }

                                               ?>
                                                                                                       
                                                </select>
                                                <input type="hidden" class="form-control" value="<?php echo $player_session; ?>" name="player_code" readonly id="" placeholder="Password">
                                                
                                                <label class="control-label col-md-6 col-sm-6 col-xs-6" for="first-name">CHOOSE ANY AVAILABLE POSITION  <span class=""></span></label>
                                                  <select class="form-control"  name="status" id="status" data-sort-order="desc" required></select>
                                                  <option  disabled selected hidden>SELECT POSITION</option>
                                                     
                                                  </div>
                                                
                                                  <div class="modal-footer centered">
                                                      <input data-dismiss="modal" class="btn btn-theme04" type="submit" name="cancel" value="cancel"/>
                                                      <input class="btn btn-primary waves-effect waves-light m-r-10" type="submit" name="enter_game" value="Submit"/>
                                                        
                                                  </div>
                                             
                                              </div>
                                           </div>
                                      </form>
                                        </div>
                                      </div>


                 
                  </div>
                  
                   
                    <div class="form-group">
                      <label for="sel1"><strong>Select Room Amount:</strong></label>
                      <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control">
                        <option value="">BTC <?php echo $btc; ?> - <?php echo $currency; ?><?php echo $zar_sa; ?></option>
                        <option value="dashboard.php">BC 00025 </option>
                        <option value="dashboard2.php">BC 0005</option>
                        <option value="dashboard3.php">BC 001</option>
                        <option value="dashboard4.php">BC 0025</option>
                        <option value="dashboard5.php">BC 005</option>
                        <option value="dashboard6.php">BC 01</option>
                        <option value="dashboard7.php">BC 025</option>
                        <option value="dashboard8.php">BC 05</option>


                      </select>
                     
                    </div>
                 
                
                </div>
                <div>
                 
                <table class="table table-striped table-bordered bootstrap-datatable datatable responsive dataTable" >
                     <thead>
    <tr>
        
 <?php
     while($row = mysqli_fetch_array($all_lists)){
                                                               
                                                                                                              
    ?> 
        
        <th><?php echo $row['name']?></th>

        <?php
                        
        }

    ?>
        
    </tr>
    </thead>
    <tbody>
           
        <tr>
     <?php
       
      $totalroom = determinetotalroom();
      $array = array();
  
       
        for($x = 0; $x < $totalroom; $x++){

        $query = "select room_".($x + 1)." as room_1, room_".($x + 2)." as room_2,room_".($x + 3)." as room_3, room_".($x + 4)." as room_4, room_".($x + 5)." as room_5 from tbl_game_bay order by game_bay_id"; 
            
        $record_list = mysqli_query($conn,$query);
       
        while($row = mysqli_fetch_array($record_list, MYSQLI_ASSOC)){

            ?>
           <td><?php echo $row['room_1']?></td>
           <td><?php echo $row['room_2']?></td>
           <td><?php echo $row['room_3']?></td>
           <td><?php echo $row['room_4']?></td>
           <td><?php echo $row['room_5']?></td>
          
              
        </tr>
            <?php
              } 
           

    }
     ?> 
       
    </tbody>
                </table>
              </div>
                <div class="row">
                  <div class="col-md-12"></div>
                  <div class="col-md-12 center-block">
                    <div class="dataTables_paginate paging_bootstrap pagination">
                      <ul class="pagination">
                        <li class="prev disabled"></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--/span-->



        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-warning">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Up Next! 2020</span>
            </div>
          </div>
        </footer>
        <!-- End of Footer -->

      </div>
      <!-- End of Content Wrapper -->


    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
 
    <div id="modal-table" class="modal fade" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header no-padding">
                                                <div class="table-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="white">&times;</span>
                                                    </button>
                                                    INVITATION OPTIONS
                                                </div>
                                            </div>

                                            <div class="modal-body no-padding">
                                                <div class="row">
                                    <div class="col-xs-12">
                                  
                                        <div class="form-group">
                                              <a href="https://api.whatsapp.com/send?phone=&text=<?php echo $whatsapp; ?>">WHATSAPP</a>
                                        </div>
                                         <div class="form-group">
                                            <a href="sms:?body=<?php echo $android; ?>">SMS (ANDROID)</a>
                                        </div>
                                         <div class="form-group">
                                            <a href="sms:;body=<?php echo $ios; ?>">SMS (IOS)</a> 
                                        </div>
                                        </div>
                                         
                                        </div>

                                    
                                        </div>
    
        

  
  </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/sb-admin-2.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
       <script>  
         $(document).ready(function(){  
              $('#room_name').change(function(){  
                   var room_name = $(this).val();  
              alert(room_name);
                   $.ajax({  
                        url:"free_spot.php",  
                        method:"POST",  
                        data:{room_name:room_name},  
                        success:function(data){  
                            $('#status').html(data);  
                        }  
                   });  
              });  
         });  
         </script>
</body>

</html>