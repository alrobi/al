 <?php  
 //load_data.php  
  $connect = mysqli_connect("169.239.217.30", "smlprojectsco_nextup", "uL75)fB@YM5I", "smlprojectsco_nextup"); 


 if(isset($_POST["amount"]))  
 {  
      if($_POST["amount"] == 'BC 0005')  
      {  
         header("location: register.php");  
      }  
      
      
 }  
 ?>