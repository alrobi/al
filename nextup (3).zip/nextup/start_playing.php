<?php 
include('connection/session.php'); 
		include('connection/connection.php'); 
		include('display/dasboard_display.php'); 
				 $status = "Paid";
		  $sql99 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status = '$status'"; 
		   
		         $detailed9 = mysqli_query($conn,$sql99);
		  while($row = mysqli_fetch_array($detailed9)){
		    $paid_ewallet = $row['amount'];

		    $available_ewallet = $availabl_ewallet - $paid_ewallet;
		  }

		$submitbutton= $_POST['enter_game'];

			$status= $_POST['status'];
		$room_name = $_POST['room_name'];
		$player_code= $_POST['player_code'];
		
		$message = '';
		$st= "Paid";
		$amount = 40.95;
		$time_date = date("Y M d ,g:1 a");
		$message = '';
		
	
				if($available_ewallet >= $amount){
						$mysql_qry = "UPDATE tbl_game_bay SET $room_name = $player_code where status = '$status' ";

					if($conn->query($mysql_qry)=== TRUE){
						
						$mysql_qry3 = "insert into tbl_wallet(player_code,amount,time_date,status)
									values('$player_code','$amount','$time_date','$st')";
									if($conn->query($mysql_qry3)=== TRUE){
										$message = 'Successfull';
										header('Location: dashboard.php');
									}
						
								  
					}else{
						
						echo "cannot perform this action".$conn->error;

						
					}
				}else{
					$message = 'Ooups refund your wallet';
					header('Location: dashboard.php');
				}
				
					
					$conn->close();
								
			

	

								   

?>