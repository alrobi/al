<?php 
include('session.php'); 
 include('connection/connection.php'); 

  $status = "verified";
  $id = $player_session;
    $result1 = mysqli_query($conn, "SELECT * FROM tbl_reg where player_code != '$id'");
    $total_player_reg = mysqli_num_rows($result1);

  $status = "Accepted";
  $inviter = $player_session;
    $result2 = mysqli_query($conn, "SELECT * FROM tbl_reg where inviter_player_code =  '$inviter' and player_code != '$id' ");
    $total_player_joined = mysqli_num_rows($result2);

 
  $sql9 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status IN ('Top Up') "; 
   
         $detailed = mysqli_query($conn,$sql9);
  while($row = mysqli_fetch_array($detailed)){
    $availabl_ewallet = $row['amount'];
  }

  $sql999 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status IN ('Withdrew')"; 
   
         $detailed9 = mysqli_query($conn,$sql999);
  while($row = mysqli_fetch_array($detailed9)){
    $total_withdrew = $row['amount'];
  }
   $sql9999 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status IN ('Earnings')"; 
   
         $detailedearned = mysqli_query($conn,$sql9999);
  while($row = mysqli_fetch_array($detailedearned)){
    $total_earning = $row['amount'];
  }

 
  $sql99 = "select sum(amount) as amount from tbl_wallet where player_code = '$player_session' and status IN ('Paid')"; 
   
         $detailed9 = mysqli_query($conn,$sql99);
  while($row = mysqli_fetch_array($detailed9)){
    $paid_ewallet = $row['amount'];

    $available_ewallet = ($availabl_ewallet - $paid_ewallet - $total_withdrew) + $total_earning;
  }

   

    //INVITATION OPTIONS
    $whatsapp = 'https://nextup.co.za/register.php?player_code='.$player_session;
    $android = 'https://nextup.co.za/register.php?player_code='.$player_session;
    $ios = 'https://nextup.co.za/register.php?player_code='.$player_session;
  

   
 


   ?>