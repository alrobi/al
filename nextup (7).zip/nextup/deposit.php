<?php 
include('session.php');
include('connection/connection.php');
		  
		$player_code = $player_session;
		$submitbutton= $_POST['submit_deposit'];
		$time_date = date("Y M d ,g:1 a");
		$status = "Top Up";
		
		$message = '';
	
    		$amount =$_POST['amount'];
   

						$mysql_qry = "insert into tbl_wallet(player_code,amount,time_date,status)
						values('$player_code','$amount','$time_date','$status')";
	
					if($conn->query($mysql_qry)=== TRUE){

						 $message = '<label class="text-danger">Successful</label>';
						header('Location: top_up.php'); 
					}else{
						$message = '<label class="text-danger">Not accepted</label>';
					}
					
						
							 
					
				
					
					$conn->close();
								
			 



?>