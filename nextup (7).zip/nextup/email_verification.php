<!DOCTYPE html>
<html>
<?php

include('connection/pdo_connection.php');

$message = '';

if(isset($_GET['activation_code']))
{
  $query = "
    SELECT * FROM tbl_reg 
    WHERE user_activation_code = :user_activation_code
  ";
  $statement = $connect->prepare($query);
  $statement->execute(
    array(
      ':user_activation_code' =>  $_GET['activation_code']
    )
  );
  $no_of_row = $statement->rowCount();
  
  if($no_of_row > 0)
  {
    $result = $statement->fetchAll();
    foreach($result as $row)
    {
      if($row['user_email_status'] == 'Not verified')
      {
        $update_query = "
        UPDATE tbl_reg 
        SET user_email_status = 'verified' 
        WHERE user_id = '".$row['user_id']."'
        ";
        $statement = $connect->prepare($update_query);
        $statement->execute();
        $sub_result = $statement->fetchAll();
        if(isset($sub_result))
        {
          $message = '<label class="text-success">Your Email Address Successfully Verified <br />You can login here - <a href="http://nextup.co.za/index.php">Login</a></label>';
        }
      }
      else
      {
        $message = '<label class="text-info">Your Email Address Already Verified</label>';
      }
    }
  }
  else
  {
    $message = '<label class="text-danger">Invalid Link</label>';
  }
}

?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Next Up! - Emal verification</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/New%20Folder/sb-admin-2.compiled.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body><div class="container">

    <h1 align="center">Email Verification</h1>
		
			<h3><?php echo $message; ?></h3>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Code injected by live-server -->
  <script type="text/javascript">
    // <![CDATA[  <-- For SVG support
    if ('WebSocket' in window) {
      (function() {
        function refreshCSS() {
          var sheets = [].slice.call(document.getElementsByTagName("link"));
          var head = document.getElementsByTagName("head")[0];
          for (var i = 0; i < sheets.length; ++i) {
            var elem = sheets[i];
            var parent = elem.parentElement || head;
            parent.removeChild(elem);
            var rel = elem.rel;
            if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
              var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
              elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
            }
            parent.appendChild(elem);
          }
        }
        var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
        var address = protocol + window.location.host + window.location.pathname + '/ws';
        var socket = new WebSocket(address);
        socket.onmessage = function(msg) {
          if (msg.data == 'reload') window.location.reload();
          else if (msg.data == 'refreshcss') refreshCSS();
        };
        if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
          console.log('Live reload enabled.');
          sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
        }
      })();
    } else {
      console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
    }
    // ]]>
  </script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/sb-admin-2.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
</body>

</html>