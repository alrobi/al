<?php

	session_start();
	$error ='';
	if(isset($_POST['submit'])){
		$message = '';
		if(empty($_POST['emailaddress']) || empty($_POST['password'])){
			$error = "Username or password is invalid";
		}else{
			$emailaddress = $_POST['emailaddress'];
			$password = $_POST['password'];

		
			  $connect = mysqli_connect("localhost:3306", "nextuhce_nextup", "*~=gBgcg#Z0i", "nextuhce_nextup"); 
			

			$emailaddress = stripslashes($emailaddress);
			$password = stripcslashes($password);

			
			$query = "SELECT * from tbl_reg where emailaddress = '$emailaddress' and password = '$password'";
			$result = mysqli_query($connect, $query);

			$record = mysqli_fetch_array($result);
			$row = mysqli_num_rows($result);
			 if($record)   
				  {  
				   if(!empty($_POST["remember"]))   
				   {  
				    setcookie ("emailaddress",$emailaddress,time()+ (10 * 365 * 24 * 60 * 60));  
				    setcookie ("password",$password,time()+ (10 * 365 * 24 * 60 * 60));
				   	$_SESSION['login_user'] = $emailaddress;
				   }  
				   else  
				   {  
				    if(isset($_COOKIE["emailaddress"]))   
				    {  
				     setcookie ("emailaddress","");  
				    }  
				    if(isset($_COOKIE["password"]))   
				    {  
				     setcookie ("password","");  
				    }  
				   }  
						  if($row > 0){
						
						$user_email_status = $record['user_email_status'];
						
						if($user_email_status == 'verified'){
							header("location: welcome.php");
						}else{
						
							$message = '<label class="text-danger">Your account is not verified.</label>';
						}

						
					}
				  }  
				  
				 }
				
				} 
			
	
?>