<?php include('connection/connection.php');  ?> 
<?php include('dashboard_display.php');  ?>
<?php
  if(isset($_POST["submit_withdrawal"]))
{

    $amount = $_POST['amount'];
    $player_code= $_POST['player_code'];
    
    $message = '';
    $status= "Withdrew";
   
    $time_date = date("Y M d ,g:1 a");
  
        if($available_ewallet >= $amount){
          // $available_ewallet = $available_ewallet - $amount;
            
            $mysql_qry3 = "insert into tbl_wallet(player_code,amount,time_date,status)
                  values('$player_code','$amount','$time_date','$status')";
                  if($conn->query($mysql_qry3)=== TRUE){
                    $message = 'Successfull';
                  header('Location: top_up.php');
                  }
            
                  
         
        }else{
          $message = 'Ooups refund your wallet';
          header('Location: top_up.php');
         
        }
        
          
          $conn->close();
                
      }
?>
