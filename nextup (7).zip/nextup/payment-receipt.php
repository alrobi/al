<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// INCLUDING DATABASE AND MAKING OBJECT
require 'classes/Database.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));

//CREATE MESSAGE ARRAY AND SET EMPTY
$msg['message'] = '';

        
        $insert_query = "INSERT INTO tbl_payment(bctxid,type,wallet_id,payment_status,currency,amount,description,created,updated,details)
                 VALUES(:bctxid,:type,:wallet_id,:payment_status,:currency,:amount,:description,:created,:updated,:details)";
        
        $insert_stmt = $conn->prepare($insert_query);
        // DATA BINDING
        $insert_stmt->bindValue(':bctxid', htmlspecialchars(strip_tags($data->bctxid)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':type', htmlspecialchars(strip_tags($data->type)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':wallet_id', htmlspecialchars(strip_tags($data->wallet_id)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':payment_status', htmlspecialchars(strip_tags($data->payment_status)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':currency', htmlspecialchars(strip_tags($data->currency)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':amount', htmlspecialchars(strip_tags($data->amount)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':description', htmlspecialchars(strip_tags($data->description)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':created', htmlspecialchars(strip_tags($data->created)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':updated', htmlspecialchars(strip_tags($data->updated)),PDO::PARAM_STR);
        $insert_stmt->bindValue(':details', htmlspecialchars(strip_tags($data->details)),PDO::PARAM_STR);
        
        if($insert_stmt->execute()){
            echo $data;
            $msg['message'] = 'Data Inserted Successfully';

        }else{
            $msg['message'] = 'Data not Inserted';
        } 
        
  
//ECHO DATA IN JSON FORMAT
echo  json_encode($msg);
?>