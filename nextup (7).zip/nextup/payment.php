<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

// INCLUDING DATABASE AND MAKING OBJECT
require __DIR__.'/classes/Database.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FORM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

// IF REQUEST METHOD IS NOT POST
if($_SERVER["REQUEST_METHOD"] != "POST"):
    $returnData = msg(0,404,'Page Not Found!');

// CHECKING EMPTY FIELDS


// IF THERE ARE NO EMPTY FIELDS THEN-
else:
    
    $bctxid = trim($data->bctxid);
    $type = trim($data->type);
    $wallet_id = trim($data->wallet_id);
    $payment_status = trim($data->payment_status);
    $currency = trim($data->currency);
    $amount = trim($data->amount);
    $description = trim($data->description);
    $created = trim($data->created);
    $updated = trim($data->updated);
    $details = trim($data->details);
    

        try{

           
                $insert_query = "INSERT INTO tbl_payment(bctxid,type,wallet_id,payment_status,currency,amount,description,created,updated,details)
                 VALUES(:bctxid,:type,:wallet_id,:payment_status,:currency,:amount,:description,:created,:updated,:details)";

                $insert_stmt = $conn->prepare($insert_query);

                // DATA BINDING
                $insert_stmt->bindValue(':bctxid', htmlspecialchars(strip_tags($bctxid)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':type', htmlspecialchars(strip_tags($type)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':wallet_id', htmlspecialchars(strip_tags($wallet_id)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':payment_status', htmlspecialchars(strip_tags($payment_status)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':currency', htmlspecialchars(strip_tags($currency)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':amount', htmlspecialchars(strip_tags($amount)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':description', htmlspecialchars(strip_tags($description)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':created', htmlspecialchars(strip_tags($created)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':updated', htmlspecialchars(strip_tags($updated)),PDO::PARAM_STR);
                $insert_stmt->bindValue(':details', htmlspecialchars(strip_tags($details)),PDO::PARAM_STR);

                $insert_stmt->execute();

                $returnData = msg(1,201,'You have successfully registered.');

           

        }
        catch(PDOException $e){
            $returnData = msg(0,500,$e->getMessage());
        }
    
    
endif;

echo json_encode($returnData);
?>
