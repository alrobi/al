<?php
// SET HEADER
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
// header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

//  INCLUDING DATABASE AND MAKING OBJECT
function isValidJSON($str) {
   json_decode($str);
   return json_last_error() == JSON_ERROR_NONE;
}


// $json_params = file_get_contents('php://input');
// Read JSON file
// on_data = file_get_contents($api_url);

// stream_get_contents($jason_params);
// $_POST['jason_params'];
$_PUT = json_decode(file_get_contents("php://input"), true);
//if (strlen($json_params) > 0 && isValidJSON($json_params))
// $data = json_decode($json_params);
// stream_get_contents($jason_params);
// }
// $data = json_decode(file_get_contents("$jsonparams"));
$data= $_PUT;

$username = "nextuhce_nextup"; 
$password = "*~=gBgcg#Z0i"; 
$host = "localhost:3306"; 
$dbase = "nextuhce_nextup";  


// Create connection
$conn = new mysqli($host, $username, $password,$dbase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


 $msg['message'] = '';
 echo $json_params;
 $wallet_id = $data->wallet_id;
 $type =  $data->type;
 $bctxid =  $data->bctxid;
 $amount =  $data->amount;
 $payment_status =  $data->payment_status;
 $description =  $data->description;
 $created =  $data->created;
 $updated =  $data->updated;
 $details =  $data->details;
        
 $insert_query = "INSERT INTO tbl_payment(bctxid,type,wallet_id,payment_status,currency,amount,description,created,updated,details)
                 VALUES(:bctxid,:type,:wallet_id,:payment_status,:currency,:amount,:description,:created,:updated,:details)";
                      

if ($conn->query($insert_query) === TRUE) {
  $last_id = $conn->insert_id;
  echo "bctxid: " . $bctxid;
  echo "type: " . $type;
  echo "wallet_id: " . $wallet_id;
  echo "payment_status" . $payment_status;
  echo "currency: " . $currency;
  echo "amount: " . $amount;
  echo "description: " . $description;
  echo "created: " . $created;
  echo "updated: " . $updated;
  echo "details: " . $details;

  echo "New record created successfully. Last inserted ID is: " . $last_id;

$sql = "commit";

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


?>
