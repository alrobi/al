<?php
include('connection/session.php'); 
     include('connection/connection.php'); 
   
         $sql2533 = "select player_code from tbl_reg where player_code = '".$_GET['player_code']."'";
   
         $full_lists33 = mysqli_query($conn,$sql2533);
         while($row = mysqli_fetch_array($full_lists33)){
            $player_code = $row['player_code'];
         }
         

            

    $pp = "";
     $status = 11;
     $statusdel = 1;
     $room = "room";
         $sql25 = "select column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay') as name where column_name like '$room%'";
   
         $full_lists = mysqli_query($conn,$sql25);
         

            
    
  ?>