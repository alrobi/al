<?php
    include('connection/session.php'); 
    include('connection/connection.php'); 
    
      
      $sql23 = "select user_id, firstname, player_code,inviter_player_code, user_email_status,emailaddress, cellno, wallet_verification from tbl_reg where player_code != '$player_session' order by player_code";
   
         $full_list = mysqli_query($conn,$sql23);

    
      
      $sql239 = "select amout, player_code from tbl_wallet";
   
         $full_listsd = mysqli_query($conn,$sql239);
         while($row = mysqli_fetch_array($full_listsd)){
            $available_ewallet = $row['amount'];
            $player_code = $row['player_code'];
            $wallet_verification ="'Not verified";
            if($available_ewallet == "" || $available_ewallet = 0){
                 $msqlodd = "UPDATE tbl_reg SET wallet_verification = '$wallet_verification' WHERE player_code = '$player_code'";
                            if($conn->query($msqlodd)=== TRUE){
                                echo "success";
                            }
            }

          }

  ?>
