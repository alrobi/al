<?php
	ob_start();
	
	 $connect = mysqli_connect("localhost:3306", "nextuhce_nextup", "*~=gBgcg#Z0i", "nextuhce_nextup"); 
	
	session_start();
	$user_check = $_SESSION['login_user'];

	
	$ses_sql = "select user_id, player_code,firstname,emailaddress from tbl_reg where emailaddress = '$user_check'";
	$result = mysqli_query($connect, $ses_sql); 
	$row = mysqli_fetch_assoc($result);
	$login_session = $row['firstname']; 
	$user_session = $row['user_id'];
	$player_session = $row['player_code'];
	$email_session = $row['emailaddress'];

	if(!isset($login_session)){
		if(($login_session == "Roland")){
			mysqli_close($connect);
		header("Location: https://nextup.co.za/index.php");
		}else{
			mysqli_close($connect);
		header("Location: https://nextup.co.za/index.php");
		}
		
	}
	
?>
