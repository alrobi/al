 <?php  
 //load_data.php  
   $connect = mysqli_connect("197.242.151.14", "nextuhce_nextup", "*~=gBgcg#Z0i", "nextuhce_nextup"); 


 if(isset($_POST["amount"]))  
 {  
      if($_POST["amount"] == 'BC 0005')  
      {  
         header("location: register.php");  
      }  
      
      
 }  
 ?>