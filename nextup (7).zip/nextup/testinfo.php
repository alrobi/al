<?php
echo phpinfo();
?>