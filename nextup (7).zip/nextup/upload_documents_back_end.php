<?php 
		include('connection/session.php');
		include('connection/connection.php'); 

		$table = "tbl_fica"; 

		$submitbutton = $_POST['uploaddocument'];

		//addrress
		$proof_of_address = $_FILES['proof_of_address']['name'];

		$tmp_name= $_FILES['proof_of_address']['tmp_name'];

		$position= strpos($proof_of_address, "."); 

		$fileextension= substr($proof_of_address, $position + 1);

		$fileextension= strtolower($fileextension);


		//id
		$proof_id = $_FILES['proof_id']['name'];

		$tmp_name2 = $_FILES['proof_id']['tmp_name'];

		$position2= strpos($proof_id, "."); 

		$fileextension2= substr($proof_id, $position2 + 1);

		$fileextension2= strtolower($fileextension2);

		
		//photo
		$photo_face = $_FILES['photo_face']['name'];

		$tmp_name3= $_FILES['photo_face']['tmp_name'];

		$position3= strpos($photo_face, "."); 

		$fileextension3= substr($photo_face, $position3 + 1);

		$fileextension3= strtolower($fileextension3);

		$message = '';


		$player_code = $player_session;
		

		$path= 'player_documents/';
		
	
					$mysql_qry = "insert into $table(player_code,proof_of_address,proof_id, photo_face)
					values('$player_code','$proof_of_address', '$proof_id', '$photo_face')";
	
					if($conn->query($mysql_qry)=== TRUE){
						
				
 $message = '<label class="text-success">Your documents were Successfully loaded <br /><a href="http://smlprojects.co.za/nextup/dashbaord.php">Dashbord</a></label>';

								   
								   header('Location: documents.php');
					}else{
						
						echo "cannot perform this action".$conn->error;
						
					}

					move_uploaded_file($tmp_name, $path.$proof_of_address);
					move_uploaded_file($tmp_name2, $path.$proof_id);
					move_uploaded_file($tmp_name3, $path.$photo_face);
				
					$conn->close();
				
					
			

	


?>