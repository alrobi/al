<?php
ob_start();
$user = "nextuhce_nextup"; 
$password = "*~=gBgcg#Z0i"; 
$host = "localhost:3306"; 
$dbase = "nextuhce_nextup";  


	$conn = mysqli_connect($host, $user, $password, $dbase) or die('unable to connect');
	if(mysqli_connect_error($conn)){
		header('Location: page_500.html');
	}
?>
