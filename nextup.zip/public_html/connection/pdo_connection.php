<?php
ob_start();
$connect = new PDO('mysql:host=localhost:3306;dbname=nextuhce_nextup', 'nextuhce_nextup', '*~=gBgcg#Z0i');
?>
