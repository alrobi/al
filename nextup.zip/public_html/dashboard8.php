<?php include('session.php');  ?> 
<!DOCTYPE html>
<?php include('connection/connection.php');  ?> 

<?php include('dashboard_display.php');  ?>
<?php
  $pp = "";
     $status = 11;
     $statusdel = 1;
     $i = 0;
     $room_number = 1;  

      //Determines how many column in the db start with room_
      $room_query = "select * from information_schema.columns where table_name='tbl_game_bay8' and column_name like 'room_%'";
      $rooms = mysqli_query($conn,$room_query);
      while($row = mysqli_fetch_array($rooms))
      {
        // echo $row['COLUMN_NAME'];
        $current_room = $row['COLUMN_NAME'];
        $room_number = str_replace('room_', '', $current_room);

        //Check that the room is full
        $query = "SELECT * FROM `tbl_game_bay8` WHERE room_{$room_number} = ''";
        $rowCount = 0;

        if ($result=mysqli_query($conn,$query))
        {
          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);
          
          // Free result set
          mysqli_free_result($result);
        }

        if(checkifroomexist($room_number)){
          if($rowcount == 0){
          //You can add a new column
                 $total = determinetotalroom();
            splitColumnifnotexist($total,$room_number,$statusdel);
            
           }
        }else{
           if($rowcount == 0){
          //You can add a new column
              splitColumn($room_number, $statusdel);
           }
        }

        $val1 = select_row_value($room_number,1);
        $val2 = select_row_value($room_number,2);
        $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

        if(empty($val1) && empty($val2)){
             $update_1_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){

                                  }
                                 }
                                }
                               }
                              }
                            } 
        }

        //if there is no empty column in room_{$room_number}, we split it
           
      //echo $sql233;
       
      }//end of while loop

      function display($room_number){
        global $conn;
         $totalroom = determinetotalroom();
    $array = array();
    for($x = 0; $x < $totalroom; $x++){
    $query = "select room_{$room_number} from tbl_game_bay8 order by game_bay_id"; 
        
      }
     }
      function checkifroomexist($room_number){
        //check if column  existing
         global $conn;
        $val = false;
          $query202 = "SELECT column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay8') as name where column_name like 'room_{$room_number}' and column_name like 'room_%'";
        
          $result202 = mysqli_query($conn,$query202);
           while($row = mysqli_fetch_array($result202))
            {
              $room_names = $row['name'];
              $val = true;
              
            }
            return $val;
      } 
      //echo checkifroomexist(2);

      function determinetotalroom(){
        //count number of column already existing
         global $conn;
         $totalroom= 0;
          $query20 = "SELECT count(*) as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay8') as name where column_name like 'room_%'";
          $total_room = 0;
          $result20=mysqli_query($conn,$query20);
           while($row = mysqli_fetch_array($result20))
            {
              $total_room = $row['name'];
              
            }
            return $total_room;
      }         
      //echo determinetotalroom();
        
        function splitColumn($room_number, $statusdel){
          global $conn;
           $pp = "";
           $null = "";

            $amount = 0.05 * 5;
           $status = "Earnings";
           $time_date = date("Y M d ,g:1 a");
          $val1 = select_row_value($room_number,1);

          $insertearn = "insert into tbl_wallet(player_code,amount,time_date,status)values('$val1','$amount','$time_date','$status')";
          if($conn->query($insertearn)=== TRUE){
            $sqldel = "UPDATE tbl_game_bay8 set room_{$room_number} = '$pp' WHERE status = '$statusdel'";
            if($conn->query($sqldel)=== TRUE){
               $sqladd = "ALTER TABLE tbl_game_bay8 ADD room_".($room_number + 1)." VARCHAR(255) not null after room_{$room_number}";
              if($conn->query($sqladd)=== TRUE){
                  $msqlodd = "UPDATE tbl_game_bay8 SET  room_".($room_number + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                    $sqleven =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){
                             $row_at_eleven = select_row_value($room_number,11);
                       if(empty($row_at_eleven)){
                        //even
                           $val_at_2 =  select_row_value($room_number,2);
                            $val_at_4 = select_row_value($room_number,4);
                            $val_at_6 = select_row_value($room_number,6);
                            $val_at_8 = select_row_value($room_number,8);
                            $val_at_10 = select_row_value($room_number,10);

                            $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

                             $update_1_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_2' WHERE game_bay_id = 1";
                            if($conn->query($update_1_even)=== TRUE){
                              $update_2_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_4' WHERE game_bay_id = 2";
                            if($coqenn->query($update_2_even)=== TRUE){
                               $update_3_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_6' WHERE game_bay_id = 3";
                            if($conn->query($update_3_even)=== TRUE){
                                   $update_4_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_8' WHERE game_bay_id = 4";
                            if($conn->query($update_4_even)=== TRUE){
                                   $update_5_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_10' WHERE game_bay_id = 5";
                            if($conn->query($update_5_even)=== TRUE){
                                   $removerow =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){
                                       $sqladdextra = "UPDATE tbl_game_bay8 set room_{$room_number} = '$val1' WHERE status = 11";
                                      if($conn->query($sqladdextra)=== TRUE){

                                      }
                                  }
                                 }
                                }
                               }
                              }
                            }
                       }else{
                            $update_1_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){
                                     $sqladdextra = "UPDATE tbl_game_bay8 set room_{$room_number} = '$val1' WHERE status = 11";
                                      if($conn->query($sqladdextra)=== TRUE){

                                      }
                                  }
                                 }
                                }
                               }
                              }
                            }
                       }
                      }
                  }
              }
            }
          }
          
             
            


        }//end of function

        function splitColumnifnotexist($totalcolumn,$room_number ,$statusdel){
          global $conn;
           $pp = "";
           $null = "";
           $amount = 0.05 * 5;
           $status = "Earnings";
           $time_date = date("Y M d ,g:1 a");
          $val1 = select_row_value($room_number,1);

          $insertearn = "insert into tbl_wallet(player_code,amount,time_date,status)values('$val1','$amount','$time_date','$status')";
          if($conn->query($insertearn)=== TRUE){
             $sqldel = "UPDATE tbl_game_bay8 set room_{$room_number} = '$pp' WHERE status = '$statusdel'"; 
         if($conn->query($sqldel)=== TRUE){
          $sqladd = "ALTER TABLE tbl_game_bay8 ADD room_".($totalcolumn + 1)." VARCHAR(255) not null after room_{$totalcolumn}";
              if($conn->query($sqladd)=== TRUE){
                 $msqlodd = "UPDATE tbl_game_bay8 SET  room_".($totalcolumn + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                     $sqleven =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){

                          $row_at_eleven = select_row_value($room_number,11);
                       if(empty($row_at_eleven)){
                        //even
                           $val_at_2 =  select_row_value($room_number,2);
                            $val_at_4 = select_row_value($room_number,4);
                            $val_at_6 = select_row_value($room_number,6);
                            $val_at_8 = select_row_value($room_number,8);
                            $val_at_10 = select_row_value($room_number,10);

                            $val_at_3 = select_row_value($room_number,3);
                            $val_at_5 =  select_row_value($room_number,5);
                            $val_at_7 =  select_row_value($room_number,7);
                            $val_at_9 =  select_row_value($room_number,9);
                            $val_at_11 =  select_row_value($room_number,11);

                             $update_1_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_2' WHERE game_bay_id = 1";
                            if($conn->query($update_1_even)=== TRUE){
                              $update_2_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_4' WHERE game_bay_id = 2";
                            if($conn->query($update_2_even)=== TRUE){
                               $update_3_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_6' WHERE game_bay_id = 3";
                            if($conn->query($update_3_even)=== TRUE){
                                   $update_4_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_8' WHERE game_bay_id = 4";
                            if($conn->query($update_4_even)=== TRUE){
                                   $update_5_even =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_10' WHERE game_bay_id = 5";
                            if($conn->query($update_5_even)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){
                                     $sqladdextra = "UPDATE tbl_game_bay8 set room_{$room_number} = '$val1' WHERE status = 11";
                                      if($conn->query($sqladdextra)=== TRUE){

                                      }
                                  }
                                 }
                                }
                               }
                              }
                            }
                       }else{
                            $update_1_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_3' WHERE game_bay_id = 1";
                            if($conn->query($update_1_odd)=== TRUE){
                              $update_2_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_5' WHERE game_bay_id = 2";
                            if($conn->query($update_2_odd)=== TRUE){
                               $update_3_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_7' WHERE game_bay_id = 3";
                            if($conn->query($update_3_odd)=== TRUE){
                                   $update_4_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_9' WHERE game_bay_id = 4";
                            if($conn->query($update_4_odd)=== TRUE){
                                   $update_5_odd =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$val_at_11' WHERE game_bay_id = 5";
                            if($conn->query($update_5_odd)=== TRUE){
                                    $removerow =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$null' WHERE game_bay_id IN (6,7,8,9,10,11)";
                            if($conn->query($removerow)=== TRUE){
                                     $sqladdextra = "UPDATE tbl_game_bay8 set room_{$room_number} = '$val1' WHERE status = 11";
                                      if($conn->query($sqladdextra)=== TRUE){

                                      }
                                  }
                                 }
                                }
                               }
                              }
                            }
                       }
                      }
                  }
              }
         }
          }

         
              
                 
  
        }//end of function

         function updaterow($room_number){
          global $conn;
           $pp = "";
          $sqldel = "UPDATE tbl_game_bay8 set room_{$room_number} = '' WHERE status = '$statusdel'";
          // echo $sqldel;

          if($conn->query($sqldel)=== TRUE){
              $sqladd = "ALTER TABLE tbl_game_bay8 ADD room_".($totalcolumn + 1)." VARCHAR(255) not null after room_{$room_number}";
              if($conn->query($sqladd)=== TRUE){
                  $msqlodd = "UPDATE tbl_game_bay8 SET  room_".($totalcolumn + 1)." = room_{$room_number} WHERE status%2 <> 0";
                  if($conn->query($msqlodd)=== TRUE){
                   $sqleven =  "UPDATE tbl_game_bay8 SET  room_{$room_number} = '$pp' WHERE status%2 <> 0";
                      if($conn->query($sqleven)=== TRUE){
                       
                      }
                    }
                }
           }


        }
        
    

      function select_row_value($room_number,$row_number){
        //count number of column already existing
         global $conn;
        
          $query200 = "SELECT room_{$room_number} as row_value from tbl_game_bay8 where game_bay_id = '$row_number'";
          
          $result200 = mysqli_query($conn,$query200);
           while($row = mysqli_fetch_array($result200))
            {
              $value = $row['row_value'];
              
            }
            return $value;
      } 

 

    //available room
    $pp = "";
     $status = 11;
     $statusdel = 1;
     $room = "room";
         $sql2555 = "select column_name as name from (SELECT * FROM information_schema.columns WHERE table_name = 'tbl_game_bay8') as name where column_name like '$room%'";
   
         $all_lists = mysqli_query($conn,$sql2555);
        

         //available room
                  

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Next Up!</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/New%20Folder/sb-admin-2.compiled.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

div.scrollmenu {
  background-color: #fff;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: #fff;
}
a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #ddd;
  color: black;
}

.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #4CAF50;
  color: white;
}

.round {
  border-radius: 50%;
}
</style>
</head>

<body><!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard8.php">
        <div class="sidebar-brand-icon">
          <i class="fa fa-angle-double-up" aria-hidden="true"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><strong>Next Up!</strong></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="dashboard8.php">
          <i class="fas fa-fw fa-home"></i>
          <span>Dashboard</span></a>
          
      </li>
      <li class="nav-item">
      </li>
     
     <li class="nav-item active">
         <a href="my_game_btc8.php" role="button" class="nav-link" >
           <i class="fas fa-gamepad"></i>
          <span>My Games</span></a>
         </a>
      </li>

      <li class="nav-item active">
         <a href="#modal-table" role="button" class="nav-link" data-toggle="modal">
           <i class="fa fa-plus" aria-hidden="true"></i>
          <span>Invite Player</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="assets/img/the-game.pdf" role="button" class="nav-link">
           <i class="fas fa-question"></i>
          <span>How to play</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="#modal-table" role="button" class="nav-link">
           <i class="fas fa-video"></i>
          <span>Videos</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a class="nav-link" href="https://www.safcoin.africa/signin" target="blank">
           <img src="assets/img/safcoin.gif"  alt="SAFCOIN" height="20em"><span >SAFCOIN</span></a>
         </a>
      </li>
         
      <li class="nav-item active">
         <a href="profile.php" role="button" class="nav-link">
           <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
          <span>Profile</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="log_out.php" role="button" class="nav-link">
           <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
          <span>Logout</span></a>
         </a>
      </li>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-warning topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md- mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="username" style="font-size: 26px;line-height: 24px;letter-spacing: 0.213em;font-weight: 500;"><?php echo $login_session; ?>
                </span>
              </a>
              <!-- Dropdown - User Information -->
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br><br>

          <!-- Content Row -->
         
          <div class="row">
             

            <!-- Total Players Card -->
            <div class="col-xl-4 col-md-4 mb-4">
              
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                        Players:</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_player_reg; ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-user fa-2x text-dark-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Total Earnings Card -->
            <div class="col-xl-4 col-md-4 mb-4">
           
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total
                        Earnings:</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_earning; ?></div>
                    </div>
                    <div class="col-auto">
                      <h3><i class="fab fa-bitcoin"></i></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Wallet Card -->
            <div class="col-xl-4 col-md-4 mb-4">
              
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Wallet:
                      </div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $available_ewallet; ?>
                          </div>

                        </div>


                      </div>
                    </div>
                    <div class="col-auto">
                    <h3><i class="fab fa-bitcoin"></i></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Players Invited Card-->
          <!--   <div class="col-xl-3 col-md-6 mb-4">
              <a href="#" class="stretched-link"></a>
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                        People joined under me:
                      </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_player_joined; ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-address-card fa-2x text-dark-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->
          </div>
          
          
            
            
          <!--Table/Game Bay-->
          <div class="row">
            <div class="box col-md-12">
              <div class="box-inner">
                
                 <div class="scrollmenu">
                  <span class="next round">&#8250;</span>
                    <a class="alert alert-info" href="welcome.php"><i class="fab fa-bitcoin"></i>0.00025</a>
                    <a class="btn btn-primary" href="dashboard2.php"><i class="fab fa-bitcoin"></i>0.0005</a>
                     <a class="btn btn-secondary" href="dashboard3.php"><i class="fab fa-bitcoin"></i>0.001</a>
                      <a class="btn btn-danger" href="dashboard4.php"><i class="fab fa-bitcoin"></i>0.0025</a>
                       <a class="btn btn-warning" href="dashboard5.php"><i class="fab fa-bitcoin"></i>0.005</a>
                        <a class="btn btn-info" href="dashboard6.php"><i class="fab fa-bitcoin"></i>0.01</a>
                         <a class="btn btn-dark" href="dashboard7.php"><i class="fab fa-bitcoin"></i>0.025</a>
                          <a class="btn btn-success" href="dashboard8.php"><i class="fab fa-bitcoin"></i>0.05</a>
                          
                          <span class="previous round">&#8249;</span>
                  </div>
                <!-- Ledger -->
             
                <!--Ledger end-->
                
                <div class="box-header well" data-original-title="">
                  <h5><i class="glyphicon glyphicon-user"></i><b> GAME HUB <i class="fab fa-bitcoin"></i>0.05</b></h5>

                  
                </div>
                 
            <div class="ledger">
              <div class="ledger-item">
                <img src="assets/img/others.jpg" ><b>OTHER</b>
                <img src="assets/img/me.jpg" ><b>YOU</b>
                <img src="assets/img/spots.jpg" ><b>GET NEXT SPOT</b>
                </div>

            </div>
     
                  
                  </div>
              
                <div>
                  <?php echo $message1; ?>
                 <div style="overflow-x:auto;">
                <table>
                     <thead>
    <tr>
        <th>No</th>
 <?php
     while($row = mysqli_fetch_array($all_lists)){
                                                               
                                                                                                              
    ?> 
        
        <th><?php echo $row['name']?></th>

        <?php
                        
        }

    ?>

        
    </tr>
    </thead>
    <tbody>
           <!-- life is hard . so the least you can do it is to be kind -->
        <tr>
     <?php
       
      $totalroom = determinetotalroom();
     

        $query = "SELECT * FROM tbl_game_bay8 order by game_bay_id"; 
        //$query = "SELECT * FROM tbl_game_bay8 WHERE room_{$room_number} = '$player_session' order by game_bay_id"; 
            
        $record_list = mysqli_query($conn,$query);
       foreach ($record_list as $row) {
             
            ?>
            <td><b><?php echo $row['status']?></b></td>
            <?php
            for($y = 0; $y < $totalroom; $y++){
               if($row['room_'.($y + 1)] == $player_session){
                   
                   $disabled = 'disabled';
                   $logo = 'me.jpg';

              }else if($row['room_'.($y + 1)] == ""){
                $logo = '';
                $row['room_'.($y + 1)] = "Secure";
                $disabled = '';
                   $logo = 'spots.jpg';      
              }else{
                
                $disabled = 'disabled';
                $logo = 'others.jpg';
              }
            
              ?>
           <td>
            
             <form class="" role="form" action="secure_btc8.php" method="get">
              <input type="hidden" class="" name="room_name" value="<?php echo ($y + 1) ?>">
                    <input type="hidden" class="" name="status" value="<?php echo $row['status'] ?>">
                    <input type="hidden" class="" name="player_code" value="<?php echo $row['room_'.($y + 1)]?>">
                    <input type="hidden" class="" name="available_amount" value="<?php echo $available_ewallet?>">
                    
                    <button type="submit" class="btn btn-link" value="<?php echo $row['room_'.($y + 1)]?>" <?php echo $disabled?> ><img class="main-logo" src="assets/img/<?php echo $logo?>" alt="" /></button>
            </form>
          </td>
                <?php
              } 
    
     ?> 
        </tr>
            <?php
              } 
           

    
     ?> 
       
    </tbody>
                </table>
              </div>
              </div>
                <div class="row">
                  <div class="col-md-12"></div>
                  <div class="col-md-12 center-block">
                    <div class="dataTables_paginate paging_bootstrap pagination">
                      <ul class="pagination">
                        <li class="prev disabled"></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--/span-->



        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-warning">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Up Next! 2020</span>
            </div>
          </div>
        </footer>
        <!-- End of Footer -->

      </div>
      <!-- End of Content Wrapper -->


    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
 
    <div id="modal-table" class="modal fade" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header no-padding">
                                                <div class="table-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="white">&times;</span>
                                                    </button>
                                                    INVITATION OPTIONS
                                                </div>
                                            </div>

                                            <div class="modal-body no-padding">
                                                <div class="row">
                                    <div class="col-xs-4">
                                  
                                        <div class="form-group">
                                              <a href="https://api.whatsapp.com/send?phone=&text=<?php echo $whatsapp; ?>"><i class="fa fa-whatsapp" style="font-size:48px;color:green"></i></a>
                                        </div>
                                         <div class="form-group">
                                            <a href="sms:?body=<?php echo $android; ?>"><i class='fas fa-sms' style='font-size:48px;color:green'></i></a>
                                        </div>
                                         <!-- <div class="form-group">
                                            <a href="sms:;body=<?php echo $ios; ?>">SMS (IOS)</a> 
                                        </div> -->
                                        </div>
                                         
                                        </div>

                                    
                                        </div>
    
        

  
  </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/sb-admin-2.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
     
</body>

</html>