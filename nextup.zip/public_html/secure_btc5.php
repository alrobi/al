<?php include('session.php');  ?> 
<!DOCTYPE html>
<?php
  $room_name = $_GET['room_name'];
  $status = $_GET['status'];
  $available_amount = $_GET['available_amount'];
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Next Up!</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/New%20Folder/sb-admin-2.compiled.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.css">
    <link rel="stylesheet" href="assets/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body><!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard5.php">
        <div class="sidebar-brand-icon">
          <i class="fa fa-angle-double-up" aria-hidden="true"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><strong>Next Up!</strong></div>
      </a>

      <!-- Divider -->
      
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="dashboard5.php">
          <i class="fas fa-fw fa-home"></i>
          <span>Dashboard</span></a>
          
      </li>
      <li class="nav-item">
      </li>
     
     <li class="nav-item active">
         <a href="my_game_btc5.php" role="button" class="nav-link" >
           <i class="fas fa-gamepad"></i>
          <span>My Games</span></a>
         </a>
      </li>

      <li class="nav-item active">
         <a href="#modal-table" role="button" class="nav-link" data-toggle="modal">
           <i class="fa fa-plus" aria-hidden="true"></i>
          <span>Invite Player</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="assets/img/the-game.pdf" role="button" class="nav-link">
           <i class="fas fa-question"></i>
          <span>How to play</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="#modal-table" role="button" class="nav-link">
           <i class="fas fa-video"></i>
          <span>Videos</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a class="nav-link" href="https://www.safcoin.africa/signin" target="blank">
           <img src="assets/img/safcoin.gif"  alt="SAFCOIN" height="20em"><span >SAFCOIN</span></a>
         </a>
      </li>
         
      <li class="nav-item active">
         <a href="profile.php" role="button" class="nav-link">
           <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
          <span>Profile</span></a>
         </a>
      </li>
      
      <li class="nav-item active">
         <a href="log_out.php" role="button" class="nav-link">
           <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
          <span>Logout</span></a>
         </a>
      </li>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-warning topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md- mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="username" style="font-size: 26px;line-height: 24px;letter-spacing: 0.213em;font-weight: 500;"><?php echo $login_session; ?><i class="fa fa-caret-down" aria-hidden="true"></i>
                </span>
              </a>
              <!-- Dropdown - User Information -->
             
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br><br>

          <!-- Content Row -->

          <!--Table-->

          <div class="row">
            <div class="box col-md-12">
              <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <h2><i class="glyphicon glyphicon-edit"></i>SECURE SPOT</h2>

                  <div class="box-icon">
                    <a href="#" class="btn btn-setting btn-round btn-default"><i class="glyphicon glyphicon-cog"></i></a>
                    <a href="#" class="btn btn-minimize btn-round btn-default"><i class="glyphicon glyphicon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round btn-default"><i class="glyphicon glyphicon-remove"></i></a>
                  </div>
                </div>
                <div class="box-content">
                  <form role="form" method="post" action="start_playing5.php">
                    <?php echo $message1; ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">UNIQUE CODE</label>
                      <input type="text" class="form-control" value="<?php echo $player_session;?>" name="player_code" readonly="" >
                      <input type="hidden" class="form-control" value="<?php echo $available_amount; ?>" name="available_amount" readonly="" >
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">SELECTED ROOM</label>
                      <input type="text" class="form-control" value="<?php echo $room_name;?>" name="room_name" readonly="" >
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">SELECTED POSITION</label>
                      <input type="text" class="form-control" value="<?php echo $status; ?>" name="status" readonly="" >
                    </div>
                    
                    
                    

                    <button type="submit" name="enter_game5" class="btn btn-primary">Submit</button>

                    <br><br>
                  </form>

                </div>
              </div>
            </div>
            <!--/span-->

          </div>


          <!-- content ends -->
        </div>
        <!--/span-->

        <!--/span-->

        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-warning">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Up Next! 2020</span>
            </div>
          </div>
        </footer>
        <!-- End of Footer -->

      </div>
      <!-- End of Content Wrapper -->


    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current
            session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="index.php">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="https:maol.mapletel.com/assets/vendor/jquery/jquery.min.js"></script>
    <script src="https://mail.mapletel.com/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="htps://mail/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="https://mail.mapletel.com/asset/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <!-- Code injected by live-server -->
    <script type="text/javascript">
      // <![CDATA[  <-- For SVG support
      if ('WebSocket' in window) {
        (function() {
          function refreshCSS() {
            var sheets = [].slice.call(document.getElementsByTagName("link"));
            var head = document.getElementsByTagName("head")[0];
            for (var i = 0; i < sheets.length; ++i) {
              var elem = sheets[i];
              var parent = elem.parentElement || head;
              parent.removeChild(elem);
              var rel = elem.rel;
              if (elem.href && typeof rel != "string" || rel.length == 0 || rel
                .toLowerCase() == "stylesheet") {
                var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
                elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') +
                  '_cacheOverride=' + (new Date().valueOf());
              }
              parent.appendChild(elem);
            }
          }
          var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
          var address = protocol + window.location.host + window.location.pathname + '/ws';
          var socket = new WebSocket(address);
          socket.onmessage = function(msg) {
            if (msg.data == 'reload') window.location.reload();
            else if (msg.data == 'refreshcss') refreshCSS();
          };
          if (sessionStorage && !sessionStorage.getItem(
              'IsThisFirstTime_Log_From_LiveServer')) {
            console.log('Live reload enabled.');
            sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
          }
        })();
      } else {
        console.error(
          'Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
      }
      // ]]>
    </script>

  </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/sb-admin-2.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
</body>

</html>