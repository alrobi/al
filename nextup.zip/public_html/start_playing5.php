<?php 
		include('session.php'); 
		include('connection/connection.php'); 
		
			

	$submitbutton = $_POST['enter_game5'];

			$status= $_POST['status'];
		$room_name = $_POST['room_name'];
		
		$available_amount= $_POST['available_amount'];
		
		$message = '';
		$st= "Paid";
		$amount = 0.005;
		$time_date = date("Y M d ,H:i:s");
		$message = '';
		 
	
				if($available_amount >= $amount){
						$mysql_qry = "UPDATE tbl_game_bay5 SET room_{$room_name} = '$player_session' where status = '$status'";

					if($conn->query($mysql_qry)=== TRUE){
						
						$mysql_qry3 = "insert into tbl_wallet(player_code,amount,time_date,status)
									values('$player_session','$amount','$time_date','$st')";
									if($conn->query($mysql_qry3)=== TRUE){
										$message1 = '<label class="text-success">Spot successfully secured.</label>';
										
										header('Location: dashboard5.php');
										
									}
						
								  
					}else{
						
						echo "cannot perform this action".$conn->error;

						
					}
				}else{
					  $message1 = '<label class="text-danger">Oups not enough crypto.</label>';
					header('Location: secure_btc5.php');
				}
				
					
					$conn->close();
								
			

	

								   

?>